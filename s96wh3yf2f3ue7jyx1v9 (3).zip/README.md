![Workflow Badge](https://img.shields.io/badge/Workflow-one_health-blue.svg)

# Workflow Name: one_health

## Description


## Processes
install_modules, raw_cancer_data, cancer_data_cleaning, radon_data_cleaning, raw_radon_data, merged_aqi, raw_birds_data, merged_aqi_cancer, merged_radon_aqi_cancer, download_data_utils, raw_aqi_data, merged_data_cleaning, birds_cleaned_data, final_merged_data

### Process Descriptions
install_modules: null
raw_cancer_data: null
cancer_data_cleaning: null
radon_data_cleaning: null
raw_radon_data: null
merged_aqi: null
raw_birds_data: null
merged_aqi_cancer: null
merged_radon_aqi_cancer: null
download_data_utils: null
raw_aqi_data: null
merged_data_cleaning: null
birds_cleaned_data: null
final_merged_data: null


## Steps to use the workflow

This section provides detailed instructions on how to use the workflow. Follow these steps to set up and execute the workflow using Geoweaver.

### Step-by-Step Instructions

### Step 1: Download the zip file
### Step 2: Import the Workflow into Geoweaver
Open Geoweaver running on your local machine. [video guidance](https://youtu.be/jUd1dzi18EQ)
1. Click on "Weaver" in the top navigation bar.
2. A workspace to add a workflow opens up. Select the "Import" icon in the top navigation bar.
3. Choose the downloaded zip file4. Click on "Start" to upload the file. If the file is valid, a prompt will ask for your permission to upload. Click "OK".
5. Once the file is uploaded, Geoweaver will create a new workflow.

### Step 3: Execute the Workflow
1. Click on the execute icon in the top navigation bar to start the workflow execution process.[video guidance](https://youtu.be/PJcMNR00QoE)
2. A wizard will open where you need to select the [video guidance](https://youtu.be/KYiEHI0rn_o) and environment [video guidance](https://www.youtube.com/watch?v=H66AVoBBaHs).
3. Click on "Execute" to initiate the workflow. Enter the required password when prompted and click "Confirm" to start executing the workflow.

### Step 4: Monitor Execution and View Results
1. The workflow execution will begin.
2. Note: Green indicates the process is successful, Yellow indicates the process is running, and Red indicates the process has failed.
3. Once the execution is complete, the results will be available immediately.

By following these steps, you will be able to set up and execute the snow cover mapping workflow using Geoweaver.
