#!/bin/bash

install require libaries
pip install pandas
pip install xlrd

#pip install selenium
#pip install selenium webdriver-manager


#wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -O ~/google-chrome-stable_current_amd64.deb

#ls -lh ~/

#mkdir -p ~/chrome_install
#dpkg-deb -x ~/google-chrome-stable_current_amd64.deb ~/chrome_install

#find ~/chrome_install -name "google-chrome"






